# TMG SMP Resource Pack

## Contributing

Open a pull request with your changes. Be sure to run `zip.sh` after making changes
 so that the `pack.zip` file updates accordingly.